INSERT INTO role (id, uuid, label, level) VALUES (1, '3529124f-b3e2-11ef-ace6-77d4c14b331d', 'SUPER_ADMIN', 3);
INSERT INTO role (id, uuid, label, level) VALUES (2, '352974b9-b3e2-11ef-ace6-77d4c14b331d', 'ADMIN', 2);
INSERT INTO role (id, uuid, label, level) VALUES (3, '352a5510-b3e2-11ef-ace6-77d4c14b331d', 'USER', 1);
INSERT INTO role (id, uuid, label, level) VALUES (4, '352ad269-b3e2-11ef-ace6-77d4c14b331d', 'UNKNOW', 0);
INSERT INTO company (email, uuid, role, name, phone) VALUES ('manager@gmail.com', '352b9b99-b3e2-11ef-ace6-77d4c14b331d', 3, 'btssio', '0641412607');
INSERT INTO room (id, uuid, company, name, street, city, zipCode, latitude, longitude, description, priceHour, priceHalfDay, priceDay, maxPeople, area, dateCreated) VALUES (1, '352c2f8c-b3e2-11ef-ace6-77d4c14b331d', "manager@gmail.com", "Hôtel Campanile Lyon", "17 Place Carnot", "Lyon", "69002", 46, 5, "Salle de réunion bien équipée", 20, 40, 100, 50, 210, '2021-02-25');
INSERT INTO room (id, uuid, company, name, street, city, zipCode, latitude, longitude, description, priceHour, priceHalfDay, priceDay, maxPeople, area, dateCreated) VALUES (2, '352ca4cc-b3e2-11ef-ace6-77d4c14b331d', "manager@gmail.com", "Hôtel Sofitel Lyon Bellecour", "20 Quai du Dr Gailleton", "Lyon", "69002", 46, 5, "Salle de réunion avec buffet", 27, 60, 120, 60, 300, '2021-03-01');
INSERT INTO room (id, uuid, company, name, street, city, zipCode, latitude, longitude, description, priceHour, priceHalfDay, priceDay, maxPeople, area, dateCreated) VALUES (3, '352d6fff-b3e2-11ef-ace6-77d4c14b331d', "manager@gmail.com", "Lyon Centre Ville", "28 Rue Notre Dame", "Lyon", "69006", 46, 5, "Salle de meeting dernier cri", 100, 400, 1000, 200, 1500, '2020-12-27');
INSERT INTO room (id, uuid, company, name, street, city, zipCode, latitude, longitude, description, priceHour, priceHalfDay, priceDay, maxPeople, area, dateCreated) VALUES (4, '352e137e-b3e2-11ef-ace6-77d4c14b331d', "manager@gmail.com", "La Maison Prune", "54 Rue Longefer", "Lyon", "69008", 46, 5, "Salle de réunion avec un décor asiatique", 16, 50, 70, 20, 200, '2021-04-16');
INSERT INTO room (id, uuid, company, name, street, city, zipCode, latitude, longitude, description, priceHour, priceHalfDay, priceDay, maxPeople, area, dateCreated) VALUES (5, '352ebcde-b3e2-11ef-ace6-77d4c14b331d', "manager@gmail.com", "Mama Shelter Lyon", "13 Rue Domer", "Lyon", "69007", 46, 5, "Salle de réunion high-tech", 60, 60, 150, 120, 900, '2021-01-10');
INSERT INTO room (id, uuid, company, name, street, city, zipCode, latitude, longitude, description, priceHour, priceHalfDay, priceDay, maxPeople, area, dateCreated) VALUES (6, '352f7597-b3e2-11ef-ace6-77d4c14b331d', "manager@gmail.com", "Montempô Lyon Cité Internationale", "35 Quai Charles de Gaulle", "Lyon", "69006", 46, 5, "Salle de réunion avec vue sur le Rhône", 200, 500, 1300, 300, 2000, '2021-03-17');
INSERT INTO room (id, uuid, company, name, street, city, zipCode, latitude, longitude, description, priceHour, priceHalfDay, priceDay, maxPeople, area, dateCreated) VALUES (7, '352ffdce-b3e2-11ef-ace6-77d4c14b331d', "manager@gmail.com", "Peexeo Coworking", "26 Rue Maurice Flandin", "Lyon", "69003", 46, 5, "Vous qui chercher à louer une salle de réunion à Lyon proche de la gare de Lyon Part-Dieu, venez nous rendre visite au sein de notre beau centre de coworking.

        Nous mettons à la disposition de nos clients une jolie salle de réunion moderne, fonctionnelle et très lumineuse. Elle est équipée d'une télévision avec connexion HDMI, un tableau blanc, un téléphone conférence et une connexion internet WIFI fibré.

        Pour votre confort, vous aurez à disposition le café et le thé en libre service ainsi que l'accès à des espaces détente.", -1, 119, 189, 4, 12, '2020-11-11');
INSERT INTO room (id, uuid, company, name, street, city, zipCode, latitude, longitude, description, priceHour, priceHalfDay, priceDay, maxPeople, area, dateCreated) VALUES (8, '35309f1b-b3e2-11ef-ace6-77d4c14b331d', "manager@gmail.com", "La Bulle Workplace", "3 Rue Fénelon", "Lyon", "69006", 46, 5, "Nous mettons en location la totalité de notre établissement situé à Lyon, dont notre salle de créativité atypique de 172m², notre mezzanine et notre espace cuisine. Cet espace de travail sera parfait pour organiser votre workshop, brainstorming, réunion d'équipe, ou tout autre événement d'entreprise.

        Ce lieu de réunion est équipé d'un grand écran, du système Clickshare, d'une estrade et de deux murs d'expression, louez notre espace de travail, laissez libre court à votre imagination et montez vos projets les plus fous !

        Plusieurs configurations sont envisageables, vous pourrez accueillir jusqu'à 40 collaborateurs. La salle est accessible du lundi au samedi de 8h à 19h en non-stop.

        Accès : Tram 1 Saxe-Préfecture, Métro A Cordeliers, Parking Morand place Maréchal Lyautey, Parking Vendôme Rue Vauban...

        Pensez à réserver votre formule de restauration pour parfaire votre journée. La maison met à votre disposition des bouteilles d'eau minérale, du café Nespresso, et du thé de la collection T en libre service.", -1, 630, 950, 40, 172, '2021-01-05');
INSERT INTO room (id, uuid, company, name, street, city, zipCode, latitude, longitude, description, priceHour, priceHalfDay, priceDay, maxPeople, area, dateCreated) VALUES (9, '3531638d-b3e2-11ef-ace6-77d4c14b331d', "manager@gmail.com", "Copark", "96 Boulevard Marius Vivier Merle", "Lyon", "69003", 46, 5, "Nous proposons la location d'une salle de réunion ou de formation permettant d’accueillir 12 personnes, dans le centre de Lyon, au coeur du quartier de la Part-Dieu. La salle est située au 1er étage de l'immeuble le Fontenoy.

        Elle dispose de :
        - Table de réunion modulable + chaises
        - 1 grand écran mural
        - 1 paper board
        - Wifi gratuit
        - Photocopies et impressions à la demande (1 € la page)
        - Boissons chaudes à disposition (café,thé)

        A quelques minutes à pied de la gare SNCF de la Part-Dieu, bus et métro à proximité.", -1, -1, 160, 12, 30, '2020-06-09');
INSERT INTO room (id, uuid, company, name, street, city, zipCode, latitude, longitude, description, priceHour, priceHalfDay, priceDay, maxPeople, area, dateCreated) VALUES (10, '3532618f-b3e2-11ef-ace6-77d4c14b331d', "manager@gmail.com", "Espace 193", "193 Rue Marcel Mérieux", "Lyon", "69007", 46, 5, "Réservez cette salle de travail spacieuse et moderne située à Lyon à deux pas du Rhône pour y organiser vos réunions d'affaires, conférences, formations, séminaires...

        Cet espace de 86m² est équipé de la WIFI, de la climatisation, d'un écran de projection, d'un paperboard, d'un espace détente (disposant d'un frigo, d'un micro onde, d'un salon et de tables) et de tous les équipements nécessaires à l'organisation d'une réunion réussie. De 45 à 65 personnes pourront rentrer dans cette salle selon sa configuration.

        Grâce à l'arrêt de métro : Debourg (ligne B) il vous sera très simple de se rendre sur place en transports en commun. Pour les personnes préférant se rendre sur les lieux en voiture, un parking privatif est à la disposition de la clientèle. Vous pourrez louer cette belle salle de réunion pour 2 heures ou plus.

        Si vous désirez déjeuner sur place, un service de restauration vous sera proposé par l'établissement. Les différentes options sont en ligne et vous pouvez dès à présent commander la formule de votre choix pour le jour J.", 150, 290, 490, 70, 86, '2020-07-14');
INSERT INTO room (id, uuid, company, name, street, city, zipCode, latitude, longitude, description, priceHour, priceHalfDay, priceDay, maxPeople, area, dateCreated) VALUES (11, '35333210-b3e2-11ef-ace6-77d4c14b331d', "manager@gmail.com", "Hotel Q7 Loge", "7 Rue Félix Brun", "Lyon", "69007", 46, 5, "Organisez vos événements professionnels dans le cadre lumineux et fonctionnel du Salon Rhône. Cette salle de séminaire située au sein d'un hôtel 4 étoiles de Lyon sera idéale pour vos réunions, formations et conférences.

        Cette salle de séminaire de 55m² est équipée de tout le matériel nécessaire au bon déroulement de vos présentations (WiFi, paper board, vidéo-projecteur, etc). L'agencement de la salle peut être modulé sur demande et vous permettra d'accueillir entre 25 et 45 personnes.

        Cette salle de séminaire, située à 2 stations de métro de la gare de Lyon Perrache, peut être louée pour au moins une heure, 7 jours sur 7. Vous pourrez bénéficier de l'accueil du personnel de l'hôtel présent 24h/24.
        Possibilité de pauses café, repas buffet ou service à l'assiette.", 95, 209, 325, 45, 55, '2020-08-15');
INSERT INTO room (id, uuid, company, name, street, city, zipCode, latitude, longitude, description, priceHour, priceHalfDay, priceDay, maxPeople, area, dateCreated) VALUES (12, '35344561-b3e2-11ef-ace6-77d4c14b331d', "manager@gmail.com", "Away Hostel and Coffee Shop", "21 Rue Alsace Lorraine", "Lyon", "69001", 46, 5, "Réservez vos rendez-vous professionnels dans l'espace « meeting room » de ce lieu atypique du 1er arrondissement de Lyon. Cette salle de réunion est pensée pour vous accueillir dans un lieu agréable et calme 7 jours/7 et 24h/24.

        Cette salle de réunion pour 15 personnes met à votre disposition un paper board, un vidéo-projecteur, bloc-notes et crayon, ainsi qu'un accès Wifi illimité. Vous pourrez également profiter d'un espace pause très cosy.

        Cette salle est idéale pour des réunions, séminaires et ateliers. Située en centre-ville, à proximité des transports en commun (Metro et Bus – Hotel de Ville), cette salle de réunion vous propose une décoration moderne, dans un immeuble ancien.", 40, 110, 185, 15, 21, '2020-06-28');
INSERT INTO room (id, uuid, company, name, street, city, zipCode, latitude, longitude, description, priceHour, priceHalfDay, priceDay, maxPeople, area, dateCreated) VALUES (13, '353518fe-b3e2-11ef-ace6-77d4c14b331d', "manager@gmail.com", "AGS Com", "24 Avenue Joannès Masset", "Lyon", "69009", 46, 5, "Organisez vos événements professionnels dans cette salle de réunion mise à disposition par un centre de coworking du 9ème arrondissement de Lyon. Cette salle est idéale pour des réunions, formations et présentations d'entreprise

        L'espace est modulable et peut accueillir 14 personnes autour d'une table en U et jusqu'à 18 personnes en format salle de classe. La salle est équipée d'une connexion WiFi et d'un paper board.

        Située à proximité de la station de métro Gorge de Loup, cette salle est disponible pour des locations à la demi-journée ou à la journée du lundi au vendredi.", -1, 82, 110, 18, 35, '2020-09-02');
INSERT INTO room (id, uuid, company, name, street, city, zipCode, latitude, longitude, description, priceHour, priceHalfDay, priceDay, maxPeople, area, dateCreated) VALUES (14, '3535c231-b3e2-11ef-ace6-77d4c14b331d', "manager@gmail.com", "Mix Coworking", "4-6 Avenue Joannes Hubert", "Tassin-la-Demi-Lune", "69160", 46, 5, "Cette salle de réunion lumineuse et climatisée peut accueillir 16 personnes autour de la table ou 20 personnes en format théâtre. Le cadre chaleureux vous permet de recevoir vos clients dans un environnement professionnel et convivial.

        Equipée d'un vidéoprojecteur, d'un paperboard et de Wi-Fi haut-débit, notre salle est idéale pour vos formations, séminaires, réunions en groupe.

        Le café et le thé sont offerts.

        Nous vous ouvrons nos portes du lundi au dimanche de 6 heures à minuit.", 40, 120, 180, 20, 35, '2020-10-14');
INSERT INTO room (id, uuid, company, name, street, city, zipCode, latitude, longitude, description, priceHour, priceHalfDay, priceDay, maxPeople, area, dateCreated) VALUES (15, '35364f1f-b3e2-11ef-ace6-77d4c14b331d', "manager@gmail.com", "Novotel Lyon Gerland Musée des Confluences", "70 Avenue Leclerc", "Lyon", "69007", 46, 5, "16 salles de réunions dont le N'Loft, espace atypique pour des réunions 'comme à la maison'
        Accès direct centre ville par Tramway
        Chambres familles & accueil enfants ++
        Face au Musée des Confluences
        Piscine et Restaurant avec terrasse", -1, 180, 320, 40, 95, '2021-03-22');
INSERT INTO room (id, uuid, company, name, street, city, zipCode, latitude, longitude, description, priceHour, priceHalfDay, priceDay, maxPeople, area, dateCreated) VALUES (16, '35374b9f-b3e2-11ef-ace6-77d4c14b331d', "manager@gmail.com", "MAPIÈCE Jacobins", "2 Rue Childebert", "Lyon", "69002", 46, 5, "Un emplacement magique pour cet écrin cosy et rare avec sa Rotonde et sa vue imprenable sur la Fontaine des Artistes, place des Jacobins.", -1, 890, 960, 15, 40, '2020-09-30');
INSERT INTO room (id, uuid, company, name, street, city, zipCode, latitude, longitude, description, priceHour, priceHalfDay, priceDay, maxPeople, area, dateCreated) VALUES (17, '35380490-b3e2-11ef-ace6-77d4c14b331d', "manager@gmail.com", "Mercure Lyon Centre Château Perrache", "12 Cours de Verdun Rambaud", "Lyon", "69002", 46, 5, "MODERNE
        Le Mercure Lyon Centre Château Perrache****, construit au début du XXème siècle, vous reçoit dans ce bâtiment historique, rénové et spacieux.
        Nos équipes vous fourniront un service personnalisé et Sur-Mesure pour répondre au mieux à vos attentes.", -1, -1, 1600, 25, 60, '2020-12-25');
INSERT INTO room (id, uuid, company, name, street, city, zipCode, latitude, longitude, description, priceHour, priceHalfDay, priceDay, maxPeople, area, dateCreated) VALUES (18, '3538c42b-b3e2-11ef-ace6-77d4c14b331d', "manager@gmail.com", "Bateau Bellona", "100 Quai Perrache", "Lyon", "69002", 46, 5, "Amarré à proximité du Musée des Confluences sur les berges du Rhône, Le Bellona vous propose 4 espaces qui s'adapteront à toutes vos réunions et évènements d'entreprise. Profitez d'une vue imprenable sur le Rhône dans un cadre unique sans vous éloigner du centre de Lyon. A bord de cette péniche, votre séminaire sera forcément un succès !", -1, 3750, 6250, 125, 280, '2020-12-31');
INSERT INTO room (id, uuid, company, name, street, city, zipCode, latitude, longitude, description, priceHour, priceHalfDay, priceDay, maxPeople, area, dateCreated) VALUES (19, '3539c5e3-b3e2-11ef-ace6-77d4c14b331d', "manager@gmail.com", "Rokoriko Basic - Réunion Créative", " 21 Quai Antoine Riboud", "Lyon", "69002", 46, 5, "Rokoriko Basic, c’est LA salle de réunion créative «originale» de Rokoriko à Lyon Confluence de 180 m2, entièrement privatisable ! Où ? Dans le 1er îlot urbain à énergie positive « Hikari » #ecologie. Pour combien ? 15 à 50 participants. Pour quoi ? #CasserLesCodes de la salle de réunion traditionnelle à papa et faire 'OMG' !", -1, 1000, 1500, 25, 180, '2021-01-01');
INSERT INTO room (id, uuid, company, name, street, city, zipCode, latitude, longitude, description, priceHour, priceHalfDay, priceDay, maxPeople, area, dateCreated) VALUES (20, '353a70bb-b3e2-11ef-ace6-77d4c14b331d', "manager@gmail.com", "Château de Montchat", "51 Rue Charles Richard", "Lyon", "69003", 46, 5, "Le Château de Montchat. est composé de 12 salons différents, communicants, de 15 à 100 m², totalisant une surface utile de 580 m² répartis entre le rez-de-jardin, le 1er et le 2ème étage. Nous sommes situé dans le 3ème arrondissement de Lyon et sommes entourés d'un parc de 3000 m²", -1, 5250, 5500, 75, 100, '2020-10-26');
INSERT INTO room (id, uuid, company, name, street, city, zipCode, latitude, longitude, description, priceHour, priceHalfDay, priceDay, maxPeople, area, dateCreated) VALUES (21, '353b2f14-b3e2-11ef-ace6-77d4c14b331d', "manager@gmail.com", "Maison Lassagne", "11 Quai André Lassagne", "Lyon", "69001", 46, 5, "MAISON LASSAGNE, en plein cœur de LYON, casse les codes du séminaire d'entreprise. Cet appartement de charme, élégant, design et chaleureux de 172 m², réhabilité façon maison de famille met la convivialité au service de la créativité, service premium à l'appui. L’atmosphère « comme à la maison » qui s’y dégage procurera une expérience inédite à vos collaborateurs ou vos clients.
        Vous êtes chez vous et Aude et Bertrand vous chouchoutent !", -1, 735, 1050, 25, 62, '2021-02-19');
INSERT INTO room (id, uuid, company, name, street, city, zipCode, latitude, longitude, description, priceHour, priceHalfDay, priceDay, maxPeople, area, dateCreated) VALUES (22, '353c118f-b3e2-11ef-ace6-77d4c14b331d', "manager@gmail.com", "Crowne Plaza Lyon Cité Internationale", "22 Quai Charles de Gaulle", "Lyon", "69006", 46, 5, "A seulement 10 minutes du centre-ville et aux pieds du centre des congrès, profitez d'un cadre lumineux et verdoyant, avec une vue imprenable sur le Rhône ou sur le fameux parc de la Tête d'Or. Le Crowne Plaza Lyon allie accessibilité et service chaleureux.
        L'hôtel propose des espaces conviviaux, confortables et parfaitement équipés. Les spécialistes événements sont disponibles sur place pour vous aider à organiser votre réunion, entretiens, ateliers.", -1, 200, 350, 75, 100, '2020-09-10');
INSERT INTO room (id, uuid, company, name, street, city, zipCode, latitude, longitude, description, priceHour, priceHalfDay, priceDay, maxPeople, area, dateCreated) VALUES (23, '353d191c-b3e2-11ef-ace6-77d4c14b331d', "manager@gmail.com", "Mama Works Lyon", "92 Cours Lafayette", "Lyon", "69003", 46, 5, "Ne vous souciez de rien, Mama s’occupe de vous !
        Notre staff Mama met son talent, sa disponibilité et sa gentillesse pour vous accompagner au quotidien et pour rendre votre expérience unique...", -1, 125, 169, 20, 40, '2021-04-20');
INSERT INTO room (id, uuid, company, name, street, city, zipCode, latitude, longitude, description, priceHour, priceHalfDay, priceDay, maxPeople, area, dateCreated) VALUES (24, '353db92c-b3e2-11ef-ace6-77d4c14b331d', "manager@gmail.com", "Escale Lyonnaise", "100 Rue de Créqui", "Lyon", "69006", 46, 5, "Dans un bâtiment de caractère au sein du quartier Foch à Lyon 6 ème.
        En ouvrant le portail, vous découvrirez une grande bâtisse avec une cour intérieure arborée.
        Arrivée à l'accueil, notre équipe vous orientera vers nos différentes salles pour vos conférences, assemblées, réunions de travail, formations et cocktails du lundi au dimanche de 08h00 à 22h00.", -1, 1100, 1250, 50, 115, '2021-04-25');
INSERT INTO room (id, uuid, company, name, street, city, zipCode, latitude, longitude, description, priceHour, priceHalfDay, priceDay, maxPeople, area, dateCreated) VALUES (25, '353e8127-b3e2-11ef-ace6-77d4c14b331d', "manager@gmail.com", "Mob Hotel - Lyon Confluence", "55 Quai Rambaud", "Lyon", "69002", 46, 5, "MOB HOTEL of the people ! République rêvée en bord de Saône.

        Rêver, Dormir, Travailler dans une atmosphère bienveillante et chaleureuse.

        Des chambres, un wifi best of the world, des matelas de palace, un restaurant bar bio, une bibliothèque, des jardins, des terrasses, du sport en plein air, une scène live, des ateliers...", -1, 450, 700, 40, 113, '2020-10-01');
INSERT INTO room (id, uuid, company, name, street, city, zipCode, latitude, longitude, description, priceHour, priceHalfDay, priceDay, maxPeople, area, dateCreated) VALUES (26, '353f459b-b3e2-11ef-ace6-77d4c14b331d', "manager@gmail.com", "Skywork", "20 Boulevard Eugène Deruelle", "Lyon", "69003", 46, 5, "Un centre d’affaires avant tout intimiste et à taille humaine pour travailler seul ou en équipe au 11ème étage de la Tour Britannia. Skywork siège dans le célèbre quartier d’affaires de la Part-Dieu, au cœur stratégique de la métropole lyonnaise, à deux pas de toutes les commodités.
        Nous mettons à disposition de nos clients un environnement de travail contemporain, calme et nous leurs proposons des services dédiés.
        A 10 minutes à pied de la Gare SNCF-TGV, Navette aéroport Rhône express.", -1, 50, 100, 8, 20, '2020-11-29');
INSERT INTO equipment (id, uuid, label) VALUES (1, '35401269-b3e2-11ef-ace6-77d4c14b331d', "Prise RJ45");
INSERT INTO equipment (id, uuid, label) VALUES (2, '3540a6ee-b3e2-11ef-ace6-77d4c14b331d', "WIFI");
INSERT INTO equipment (id, uuid, label) VALUES (3, '35419001-b3e2-11ef-ace6-77d4c14b331d', "Climatisation");
INSERT INTO equipment (id, uuid, label) VALUES (4, '35421783-b3e2-11ef-ace6-77d4c14b331d', "Tableau");
INSERT INTO equipment (id, uuid, label) VALUES (5, '3542b06a-b3e2-11ef-ace6-77d4c14b331d', "Projecteur");
INSERT INTO equipment (id, uuid, label) VALUES (6, '35436f4a-b3e2-11ef-ace6-77d4c14b331d', "Téléviseur");
INSERT INTO equipment (id, uuid, label) VALUES (7, '354421eb-b3e2-11ef-ace6-77d4c14b331d', "Bouteille d'eau");
INSERT INTO equipment (id, uuid, label) VALUES (8, '3544c952-b3e2-11ef-ace6-77d4c14b331d', "Stylo et bloc note");
INSERT INTO equipment (id, uuid, label) VALUES (9, '35455f7b-b3e2-11ef-ace6-77d4c14b331d', "Fibre optique");
INSERT INTO equipment (id, uuid, label) VALUES (10, '35465c9e-b3e2-11ef-ace6-77d4c14b331d', "ADSL");
INSERT INTO equipment (id, uuid, label) VALUES (11, '3547805a-b3e2-11ef-ace6-77d4c14b331d', "Prise électrique");
INSERT INTO equipment (id, uuid, label) VALUES (12, '35483e01-b3e2-11ef-ace6-77d4c14b331d', "Paper board");
INSERT INTO equipment (id, uuid, label) VALUES (13, '35490c73-b3e2-11ef-ace6-77d4c14b331d', "Visioconférence");
INSERT INTO equipment (id, uuid, label) VALUES (14, '3549c404-b3e2-11ef-ace6-77d4c14b331d', "Fontaine à eau");
INSERT INTO equipment (id, uuid, label) VALUES (15, '354a5e3b-b3e2-11ef-ace6-77d4c14b331d', "Café inclus");
INSERT INTO equipment (id, uuid, label) VALUES (16, '354b0c90-b3e2-11ef-ace6-77d4c14b331d', "Ordinateur");
INSERT INTO equipment (id, uuid, label) VALUES (17, '354bd3bb-b3e2-11ef-ace6-77d4c14b331d', "Photocopieuse");
INSERT INTO equipment (id, uuid, label) VALUES (18, '354c7158-b3e2-11ef-ace6-77d4c14b331d', "Lieux vérifé");
INSERT INTO equip (equipment, room) VALUES (2, 1);
INSERT INTO equip (equipment, room) VALUES (3, 1);
INSERT INTO equip (equipment, room) VALUES (12, 1);
INSERT INTO equip (equipment, room) VALUES (16, 1);
INSERT INTO equip (equipment, room) VALUES (17, 1);
INSERT INTO equip (equipment, room) VALUES (18, 1);
INSERT INTO equip (equipment, room) VALUES (1, 2);
INSERT INTO equip (equipment, room) VALUES (2, 2);
INSERT INTO equip (equipment, room) VALUES (7, 2);
INSERT INTO equip (equipment, room) VALUES (8, 2);
INSERT INTO equip (equipment, room) VALUES (2, 3);
INSERT INTO equip (equipment, room) VALUES (4, 3);
INSERT INTO equip (equipment, room) VALUES (6, 3);
INSERT INTO equip (equipment, room) VALUES (7, 3);
INSERT INTO equip (equipment, room) VALUES (10, 3);
INSERT INTO equip (equipment, room) VALUES (15, 3);
INSERT INTO equip (equipment, room) VALUES (18, 3);
INSERT INTO equip (equipment, room) VALUES (2, 4);
INSERT INTO equip (equipment, room) VALUES (4, 4);
INSERT INTO equip (equipment, room) VALUES (6, 4);
INSERT INTO equip (equipment, room) VALUES (7, 4);
INSERT INTO equip (equipment, room) VALUES (10, 4);
INSERT INTO equip (equipment, room) VALUES (15, 4);
INSERT INTO equip (equipment, room) VALUES (18, 4);
INSERT INTO equip (equipment, room) VALUES (2, 5);
INSERT INTO equip (equipment, room) VALUES (4, 5);
INSERT INTO equip (equipment, room) VALUES (6, 5);
INSERT INTO equip (equipment, room) VALUES (7, 5);
INSERT INTO equip (equipment, room) VALUES (10, 5);
INSERT INTO equip (equipment, room) VALUES (15, 5);
INSERT INTO equip (equipment, room) VALUES (18, 5);
INSERT INTO equip (equipment, room) VALUES (2, 6);
INSERT INTO equip (equipment, room) VALUES (4, 6);
INSERT INTO equip (equipment, room) VALUES (6, 6);
INSERT INTO equip (equipment, room) VALUES (7, 6);
INSERT INTO equip (equipment, room) VALUES (10, 6);
INSERT INTO equip (equipment, room) VALUES (15, 6);
INSERT INTO equip (equipment, room) VALUES (18, 6);
INSERT INTO equip (equipment, room) VALUES (2, 7);
INSERT INTO equip (equipment, room) VALUES (4, 7);
INSERT INTO equip (equipment, room) VALUES (6, 7);
INSERT INTO equip (equipment, room) VALUES (7, 7);
INSERT INTO equip (equipment, room) VALUES (10, 7);
INSERT INTO equip (equipment, room) VALUES (15, 7);
INSERT INTO equip (equipment, room) VALUES (18, 7);
INSERT INTO equip (equipment, room) VALUES (2, 8);
INSERT INTO equip (equipment, room) VALUES (4, 8);
INSERT INTO equip (equipment, room) VALUES (6, 8);
INSERT INTO equip (equipment, room) VALUES (7, 8);
INSERT INTO equip (equipment, room) VALUES (10, 8);
INSERT INTO equip (equipment, room) VALUES (15, 8);
INSERT INTO equip (equipment, room) VALUES (18, 8);
INSERT INTO equip (equipment, room) VALUES (2, 9);
INSERT INTO equip (equipment, room) VALUES (4, 9);
INSERT INTO equip (equipment, room) VALUES (6, 9);
INSERT INTO equip (equipment, room) VALUES (7, 9);
INSERT INTO equip (equipment, room) VALUES (10, 9);
INSERT INTO equip (equipment, room) VALUES (15, 9);
INSERT INTO equip (equipment, room) VALUES (18, 9);
INSERT INTO equip (equipment, room) VALUES (2, 10);
INSERT INTO equip (equipment, room) VALUES (4, 10);
INSERT INTO equip (equipment, room) VALUES (6, 10);
INSERT INTO equip (equipment, room) VALUES (7, 10);
INSERT INTO equip (equipment, room) VALUES (10, 10);
INSERT INTO equip (equipment, room) VALUES (15, 10);
INSERT INTO equip (equipment, room) VALUES (18, 10);
INSERT INTO equip (equipment, room) VALUES (2, 11);
INSERT INTO equip (equipment, room) VALUES (4, 11);
INSERT INTO equip (equipment, room) VALUES (6, 11);
INSERT INTO equip (equipment, room) VALUES (7, 11);
INSERT INTO equip (equipment, room) VALUES (10, 11);
INSERT INTO equip (equipment, room) VALUES (15, 11);
INSERT INTO equip (equipment, room) VALUES (18, 11);
INSERT INTO equip (equipment, room) VALUES (2, 12);
INSERT INTO equip (equipment, room) VALUES (4, 12);
INSERT INTO equip (equipment, room) VALUES (6, 12);
INSERT INTO equip (equipment, room) VALUES (7, 12);
INSERT INTO equip (equipment, room) VALUES (10, 12);
INSERT INTO equip (equipment, room) VALUES (15, 12);
INSERT INTO equip (equipment, room) VALUES (18, 12);
INSERT INTO equip (equipment, room) VALUES (2, 13);
INSERT INTO equip (equipment, room) VALUES (4, 13);
INSERT INTO equip (equipment, room) VALUES (6, 13);
INSERT INTO equip (equipment, room) VALUES (7, 13);
INSERT INTO equip (equipment, room) VALUES (10, 13);
INSERT INTO equip (equipment, room) VALUES (15, 13);
INSERT INTO equip (equipment, room) VALUES (18, 13);
INSERT INTO equip (equipment, room) VALUES (2, 14);
INSERT INTO equip (equipment, room) VALUES (4, 14);
INSERT INTO equip (equipment, room) VALUES (6, 14);
INSERT INTO equip (equipment, room) VALUES (7, 14);
INSERT INTO equip (equipment, room) VALUES (10, 14);
INSERT INTO equip (equipment, room) VALUES (15, 14);
INSERT INTO equip (equipment, room) VALUES (18, 14);
INSERT INTO equip (equipment, room) VALUES (2, 15);
INSERT INTO equip (equipment, room) VALUES (4, 15);
INSERT INTO equip (equipment, room) VALUES (6, 15);
INSERT INTO equip (equipment, room) VALUES (7, 15);
INSERT INTO equip (equipment, room) VALUES (10, 15);
INSERT INTO equip (equipment, room) VALUES (15, 15);
INSERT INTO equip (equipment, room) VALUES (18, 15);
INSERT INTO equip (equipment, room) VALUES (2, 16);
INSERT INTO equip (equipment, room) VALUES (4, 16);
INSERT INTO equip (equipment, room) VALUES (6, 16);
INSERT INTO equip (equipment, room) VALUES (7, 16);
INSERT INTO equip (equipment, room) VALUES (10, 16);
INSERT INTO equip (equipment, room) VALUES (15, 16);
INSERT INTO equip (equipment, room) VALUES (18, 16);
INSERT INTO equip (equipment, room) VALUES (2, 17);
INSERT INTO equip (equipment, room) VALUES (4, 17);
INSERT INTO equip (equipment, room) VALUES (6, 17);
INSERT INTO equip (equipment, room) VALUES (7, 17);
INSERT INTO equip (equipment, room) VALUES (10, 17);
INSERT INTO equip (equipment, room) VALUES (15, 17);
INSERT INTO equip (equipment, room) VALUES (18, 17);
INSERT INTO equip (equipment, room) VALUES (2, 18);
INSERT INTO equip (equipment, room) VALUES (4, 18);
INSERT INTO equip (equipment, room) VALUES (6, 18);
INSERT INTO equip (equipment, room) VALUES (7, 18);
INSERT INTO equip (equipment, room) VALUES (10, 18);
INSERT INTO equip (equipment, room) VALUES (15, 18);
INSERT INTO equip (equipment, room) VALUES (18, 18);
INSERT INTO equip (equipment, room) VALUES (2, 19);
INSERT INTO equip (equipment, room) VALUES (4, 19);
INSERT INTO equip (equipment, room) VALUES (6, 19);
INSERT INTO equip (equipment, room) VALUES (7, 19);
INSERT INTO equip (equipment, room) VALUES (10, 19);
INSERT INTO equip (equipment, room) VALUES (15, 19);
INSERT INTO equip (equipment, room) VALUES (18, 19);
INSERT INTO equip (equipment, room) VALUES (2, 20);
INSERT INTO equip (equipment, room) VALUES (4, 20);
INSERT INTO equip (equipment, room) VALUES (6, 20);
INSERT INTO equip (equipment, room) VALUES (7, 20);
INSERT INTO equip (equipment, room) VALUES (10, 20);
INSERT INTO equip (equipment, room) VALUES (15, 20);
INSERT INTO equip (equipment, room) VALUES (18, 20);
INSERT INTO equip (equipment, room) VALUES (2, 21);
INSERT INTO equip (equipment, room) VALUES (4, 21);
INSERT INTO equip (equipment, room) VALUES (6, 21);
INSERT INTO equip (equipment, room) VALUES (7, 21);
INSERT INTO equip (equipment, room) VALUES (10, 21);
INSERT INTO equip (equipment, room) VALUES (15, 21);
INSERT INTO equip (equipment, room) VALUES (18, 21);
INSERT INTO equip (equipment, room) VALUES (2, 22);
INSERT INTO equip (equipment, room) VALUES (4, 22);
INSERT INTO equip (equipment, room) VALUES (6, 22);
INSERT INTO equip (equipment, room) VALUES (7, 22);
INSERT INTO equip (equipment, room) VALUES (10, 22);
INSERT INTO equip (equipment, room) VALUES (15, 22);
INSERT INTO equip (equipment, room) VALUES (18, 22);
INSERT INTO equip (equipment, room) VALUES (2, 23);
INSERT INTO equip (equipment, room) VALUES (4, 23);
INSERT INTO equip (equipment, room) VALUES (6, 23);
INSERT INTO equip (equipment, room) VALUES (7, 23);
INSERT INTO equip (equipment, room) VALUES (10, 23);
INSERT INTO equip (equipment, room) VALUES (15, 23);
INSERT INTO equip (equipment, room) VALUES (18, 23);
INSERT INTO equip (equipment, room) VALUES (2, 24);
INSERT INTO equip (equipment, room) VALUES (4, 24);
INSERT INTO equip (equipment, room) VALUES (6, 24);
INSERT INTO equip (equipment, room) VALUES (7, 24);
INSERT INTO equip (equipment, room) VALUES (10, 24);
INSERT INTO equip (equipment, room) VALUES (15, 24);
INSERT INTO equip (equipment, room) VALUES (18, 24);
INSERT INTO equip (equipment, room) VALUES (2, 25);
INSERT INTO equip (equipment, room) VALUES (4, 25);
INSERT INTO equip (equipment, room) VALUES (6, 25);
INSERT INTO equip (equipment, room) VALUES (7, 25);
INSERT INTO equip (equipment, room) VALUES (10, 25);
INSERT INTO equip (equipment, room) VALUES (15, 25);
INSERT INTO equip (equipment, room) VALUES (18, 25);
INSERT INTO equip (equipment, room) VALUES (2, 26);
INSERT INTO equip (equipment, room) VALUES (4, 26);
INSERT INTO equip (equipment, room) VALUES (6, 26);
INSERT INTO equip (equipment, room) VALUES (7, 26);
INSERT INTO equip (equipment, room) VALUES (10, 26);
INSERT INTO equip (equipment, room) VALUES (15, 26);
INSERT INTO equip (equipment, room) VALUES (18, 26);
INSERT INTO image (id, uuid, path, room) VALUES (1, '35bc30a5-b3e2-11ef-ace6-77d4c14b331d', 'http://192.168.1.63/Images/imgRoom_1.jpg', 1);
INSERT INTO image (id, uuid, path, room) VALUES (2, '35bc82a0-b3e2-11ef-ace6-77d4c14b331d', 'http://192.168.1.63/Images/imgRoom_2.jpg', 2);
INSERT INTO image (id, uuid, path, room) VALUES (3, '35bd132e-b3e2-11ef-ace6-77d4c14b331d', 'http://192.168.1.63/Images/imgRoom_3.jpeg', 3);
INSERT INTO image (id, uuid, path, room) VALUES (4, '35bdd5ac-b3e2-11ef-ace6-77d4c14b331d', 'http://192.168.1.63/Images/imgRoom_4.jpg', 4);
INSERT INTO image (id, uuid, path, room) VALUES (5, '35be7dae-b3e2-11ef-ace6-77d4c14b331d', 'http://192.168.1.63/Images/imgRoom_5.jpg', 5);
INSERT INTO image (id, uuid, path, room) VALUES (6, '35bf2541-b3e2-11ef-ace6-77d4c14b331d', 'http://192.168.1.63/Images/imgRoom_6.jpg', 6);
INSERT INTO image (id, uuid, path, room) VALUES (7, '35c05425-b3e2-11ef-ace6-77d4c14b331d', 'http://192.168.1.63/Images/imgRoom_7.jpg', 7);
INSERT INTO image (id, uuid, path, room) VALUES (8, '35c12a89-b3e2-11ef-ace6-77d4c14b331d', 'http://192.168.1.63/Images/imgRoom_8.jpg', 8);
INSERT INTO image (id, uuid, path, room) VALUES (9, '35c1cf4e-b3e2-11ef-ace6-77d4c14b331d', 'http://192.168.1.63/Images/imgRoom_9.jpg', 9);
INSERT INTO image (id, uuid, path, room) VALUES (10, '35c26606-b3e2-11ef-ace6-77d4c14b331d', 'http://192.168.1.63/Images/imgRoom_10.jpg', 10);
INSERT INTO image (id, uuid, path, room) VALUES (11, '35c312ef-b3e2-11ef-ace6-77d4c14b331d', 'http://192.168.1.63/Images/imgRoom_11.jpg', 11);
INSERT INTO image (id, uuid, path, room) VALUES (12, '35c39e37-b3e2-11ef-ace6-77d4c14b331d', 'http://192.168.1.63/Images/imgRoom_12.jpg', 12);
INSERT INTO image (id, uuid, path, room) VALUES (13, '35c43ec1-b3e2-11ef-ace6-77d4c14b331d', 'http://192.168.1.63/Images/imgRoom_13.jpg', 13);
INSERT INTO image (id, uuid, path, room) VALUES (14, '35c51cef-b3e2-11ef-ace6-77d4c14b331d', 'http://192.168.1.63/Images/imgRoom_14.jpg', 14);
INSERT INTO image (id, uuid, path, room) VALUES (15, '35c5db62-b3e2-11ef-ace6-77d4c14b331d', 'http://192.168.1.63/Images/imgRoom_15.jpg', 15);
INSERT INTO image (id, uuid, path, room) VALUES (16, '35c66732-b3e2-11ef-ace6-77d4c14b331d', 'http://192.168.1.63/Images/imgRoom_16.jpg', 16);
INSERT INTO image (id, uuid, path, room) VALUES (17, '35c6f6ed-b3e2-11ef-ace6-77d4c14b331d', 'http://192.168.1.63/Images/imgRoom_17.jpg', 17);
INSERT INTO image (id, uuid, path, room) VALUES (18, '35c79968-b3e2-11ef-ace6-77d4c14b331d', 'http://192.168.1.63/Images/imgRoom_18.jpg', 18);
INSERT INTO image (id, uuid, path, room) VALUES (19, '35c88b07-b3e2-11ef-ace6-77d4c14b331d', 'http://192.168.1.63/Images/imgRoom_19.jpg', 19);
INSERT INTO image (id, uuid, path, room) VALUES (20, '35c92cfe-b3e2-11ef-ace6-77d4c14b331d', 'http://192.168.1.63/Images/imgRoom_20.jpg', 20);
INSERT INTO image (id, uuid, path, room) VALUES (21, '35cc3e36-b3e2-11ef-ace6-77d4c14b331d', 'http://192.168.1.63/Images/imgRoom_21.jpg', 21);
INSERT INTO image (id, uuid, path, room) VALUES (22, '35ccb829-b3e2-11ef-ace6-77d4c14b331d', 'http://192.168.1.63/Images/imgRoom_22.jpg', 22);
INSERT INTO image (id, uuid, path, room) VALUES (23, '35cd683b-b3e2-11ef-ace6-77d4c14b331d', 'http://192.168.1.63/Images/imgRoom_23.jpg', 23);
INSERT INTO image (id, uuid, path, room) VALUES (24, '35ce0f75-b3e2-11ef-ace6-77d4c14b331d', 'http://192.168.1.63/Images/imgRoom_24.jpg', 24);
INSERT INTO image (id, uuid, path, room) VALUES (25, '35cee6b0-b3e2-11ef-ace6-77d4c14b331d', 'http://192.168.1.63/Images/imgRoom_25.jpg', 25);
INSERT INTO image (id, uuid, path, room) VALUES (26, '35cfc509-b3e2-11ef-ace6-77d4c14b331d', 'http://192.168.1.63/Images/imgRoom_26.jpg', 26);
